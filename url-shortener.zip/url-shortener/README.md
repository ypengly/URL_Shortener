# ShortLink — Setup Instructions

These files are a **drop-in overlay** for a fresh Laravel project — they are
not a full Laravel installation themselves (Laravel's core framework files
aren't included). Follow the steps below in order.

## 1. Check PHP and Composer

```powershell
php -v
composer -V
```

You need PHP 8.2+ and Composer 2.x. If either command fails, install them first.

## 2. Create a fresh Laravel project

```powershell
composer create-project laravel/laravel url-shortener
cd url-shortener
```

## 3. Install Laravel Breeze (simple login/register/logout scaffolding)

```powershell
composer require laravel/breeze --dev
php artisan breeze:install blade
npm install
npm run build
```

This generates `routes/auth.php`, login/register Blade views, and a working
`User` model with authentication already wired up — so we don't have to
write login/password logic by hand.

## 4. Copy in the files from this project

Copy these files/folders from this download into your new `url-shortener`
project, **overwriting** where prompted:

```
app/Models/Url.php                              → app/Models/Url.php
app/Http/Controllers/UrlController.php           → app/Http/Controllers/UrlController.php
database/migrations/2024_01_01_000000_create_urls_table.php → database/migrations/
routes/web.php                                   → routes/web.php (overwrite)
resources/views/layouts/app.blade.php            → resources/views/layouts/app.blade.php
resources/views/home.blade.php                   → resources/views/home.blade.php
resources/views/dashboard.blade.php              → resources/views/dashboard.blade.php
resources/views/errors/404.blade.php             → resources/views/errors/404.blade.php
public/css/app.css                               → public/css/app.css
public/js/app.js                                 → public/js/app.js
```

Then open `app/Models/User.php` (the one Breeze generated) and add this
method inside the class, from the `User.php` in this download:

```php
public function urls()
{
    return $this->hasMany(Url::class);
}
```

## 5. Create the MySQL database

Open MySQL (e.g. via `mysql -u root -p`) and run:

```sql
CREATE DATABASE url_shortener;
```

## 6. Configure `.env`

Open `.env` in the project root and set:

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=url_shortener
DB_USERNAME=root
DB_PASSWORD=your_mysql_password
```

## 7. Run migrations

```powershell
php artisan migrate
```

## 8. Start the server

```powershell
php artisan serve
```

## 9. Open the app

Visit:

```
http://127.0.0.1:8000
```

Register an account at `/register`, log in, and try shortening a URL.
